# Frontend Catalog UX
Карточка должна показывать: name, transports, `protocol_min` (датой), primitives, `client_matrix`, ссылки (repo/homepage), бейджи категории (reference/official/hosted).
Для hosted — endpoint и «как подключить» (микро-сниппет).
