# Security & Transport Auditor
Чек-лист: STDIO — нет логов в stdout; Streamable HTTP — обязательная аутентификация, проверка Origin, локально — bind на localhost.
Выход: бейдж `security_ok|warn|fail` и конкретные рекомендации.
