---
name: "Bug report"
about: Report a problem with a manifest or schema
labels: ["bug"]
---

**What happened?**

**Steps to reproduce**

**Expected**

**Additional context**