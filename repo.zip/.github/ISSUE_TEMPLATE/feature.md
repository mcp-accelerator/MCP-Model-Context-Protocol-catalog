---
name: "Feature request"
about: Request a new feature for the catalog
labels: ["feature"]
---

**What problem are you solving?**

**Proposed solution**

**Alternatives**

**Additional context**